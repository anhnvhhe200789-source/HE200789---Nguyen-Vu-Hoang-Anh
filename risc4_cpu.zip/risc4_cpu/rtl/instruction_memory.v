`timescale 1ns / 1ps
// instruction_memory.v - 16 x 12-bit ROM, loaded from a .mem file (hex, one word per line)
module instruction_memory #(
    parameter PROGRAM_FILE = "program.mem"
)(
    input  [3:0]  address,
    output [11:0] instruction
);
    reg [11:0] mem [0:15];
    integer i;

    initial begin
        for (i = 0; i < 16; i = i + 1)
            mem[i] = 12'hC00;            // C00 = reserved opcode = NOP
        $readmemh(PROGRAM_FILE, mem);
    end

    assign instruction = mem[address];
endmodule
