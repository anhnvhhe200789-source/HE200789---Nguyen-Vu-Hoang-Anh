# 4-bit RISC CPU (3-stage pipeline) - Vivado project files

    rtl/   11 design files   -> Vivado: Add Sources > Add or create DESIGN sources
    sim/    4 testbenches    -> Vivado: Add Sources > Add or create SIMULATION sources
    mem/    4 program files  -> Vivado: SIMULATION sources too (file type: Memory/Data files)
    expected_results.txt     -> output you should see (88 / 88 checks PASS)

Top module for synthesis : cpu_top
Top module for simulation: tb_alu, tb_register_file, tb_control_unit, tb_cpu (one at a time)
Run order: tb_alu -> tb_register_file -> tb_control_unit -> tb_cpu
